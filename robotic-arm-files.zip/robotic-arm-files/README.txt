Desktop Robotic Arm - STL files and drawings
Designed by Ryan Schaller in Autodesk Fusion 360
Portfolio: https://ryanschaller.github.io

Parts, base to gripper (print 1 of each, units in mm):
  1. base.stl            78.0 x 50.0 x 68.0
  2. shoulder.stl        49.0 x 53.8 x 45.8
  3. shoulderRaise.stl  161.0 x 45.0 x 45.5
  4. wristFlex.stl       99.6 x 45.0 x 45.4
  5. wristTwist.stl      65.5 x 45.0 x 45.4
  6. gripperBase.stl     69.8 x 41.0 x 99.0
  7. gripperClaw.stl    104.5 x 20.0 x 46.9

Folders:
  stl/       printable part files
  drawings/  dimensioned drawing of each part (PNG), plus all-drawings.pdf
